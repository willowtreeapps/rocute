# Next

### Description
The 'Next' component is an stubbed out component for development. If you are interested in
contributing, this component is here to help.
To utilize this tool,
 - Remove the commented lines regarding the 'Next' component in the MainListPanel.brs and
 MainPanelList.xml files.
 - Modify the contents of the Next and NextExample directories to create your component.
 - Move the components to their own directories following the standard set by the Next directories 
 outline, and return the Next directories to their original standard.
 - Re-comment the lines regarding the 'Next' component in the MainListPanel.brs and
 MainPanelList.xml files.
 - Create a pull request.

### Usage
| Field | Type | Default | Options | Required | Access Permission | Description |
| ----------- | ----------- | ----------- | ----------- | ----------- | ----------- | ----------- |
|  |  |  |  |  |  |  |